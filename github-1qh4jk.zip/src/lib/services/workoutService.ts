import { pb } from '$lib/pocketbase';
import type { WorkoutSet, WorkoutExercise } from '$lib/types';

export interface PreviousSetInfo {
    weight: number;
    reps: number;
}

export async function getPreviousSetInfo(exerciseId: string, setNumber: number): Promise<PreviousSetInfo | null> {
    try {
        // Get the most recent completed workout that includes this exercise
        const result = await pb.send('/api/collections/workout_exercises/records', {
            method: 'GET',
            params: {
                filter: `exercise = "${exerciseId}"`,
                expand: 'workout',
                sort: '-created',
                $cancelKey: new AbortController().signal
            }
        });

        if (!result?.items?.length) {
            return null;
        }

        // Find the most recent completed workout exercise
        const workoutExercise = result.items.find((we: any) => 
            we?.expand?.workout?.status === 'completed'
        );

        if (!workoutExercise) {
            return null;
        }

        // Get the specific set from that workout exercise
        const sets = await pb.collection('workout_sets').getList<WorkoutSet>(1, 1, {
            filter: `workout_exercise = "${workoutExercise.id}" && set_number = ${setNumber}`,
            sort: '-created'
        });

        if (sets.items.length === 0) {
            return null;
        }

        const set = sets.items[0];
        return {
            weight: set.weight,
            reps: set.reps
        };
    } catch (e) {
        console.error('Error fetching previous set info:', e);
        return null;
    }
}