<script lang="ts">
    import { onMount } from 'svelte';
    import LoadingSpinner from '../LoadingSpinner.svelte';
    import { getPreviousSetInfo, type PreviousSetInfo } from '$lib/services/workoutService';
    
    export let exerciseId: string;
    export let setNumber: number;
    
    let previousSetInfo: PreviousSetInfo | null = null;
    let loading = true;
    
    onMount(async () => {
        if (!exerciseId) {
            loading = false;
            return;
        }

        try {
            previousSetInfo = await getPreviousSetInfo(exerciseId, setNumber);
        } catch (e) {
            console.error('Error loading previous set info:', e);
            previousSetInfo = null;
        } finally {
            loading = false;
        }
    });
</script>

<div class="mt-1">
    {#if loading}
        <div class="flex items-center gap-2 text-surface-500">
            <LoadingSpinner size="sm" />
            <span>Loading previous set info...</span>
        </div>
    {:else if previousSetInfo !== null}
        <div class="text-lg font-bold text-primary-500">
            Previous set: {previousSetInfo.weight}kg × {previousSetInfo.reps} reps
        </div>
    {:else}
        <span class="text-surface-500">No previous data available</span>
    {/if}
</div>