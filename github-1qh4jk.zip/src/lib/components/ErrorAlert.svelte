<script lang="ts">
    export let message: string;
</script>

<div class="alert variant-filled-error">
    <span class="font-semibold">{message}</span>
</div>