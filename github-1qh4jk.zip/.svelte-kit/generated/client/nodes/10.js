import * as universal from "../../../../src/routes/workouts/new/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/workouts/new/+page.svelte";