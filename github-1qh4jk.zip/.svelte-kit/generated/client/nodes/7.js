import * as universal from "../../../../src/routes/workouts/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/workouts/+page.svelte";