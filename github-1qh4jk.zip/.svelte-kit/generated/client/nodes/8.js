import * as universal from "../../../../src/routes/workouts/[id]/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/workouts/[id]/+page.svelte";