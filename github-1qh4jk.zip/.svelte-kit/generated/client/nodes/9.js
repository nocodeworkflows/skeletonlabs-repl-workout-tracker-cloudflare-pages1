import * as universal from "../../../../src/routes/workouts/[id]/track/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/workouts/[id]/track/+page.svelte";